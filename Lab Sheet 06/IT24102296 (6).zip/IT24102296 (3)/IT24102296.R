setwd("C:\\Users\\USER\\Desktop\\IT24102296 (3)")

#Question 01 part 01
n <- 44
p <- 0.92

#Question 01 part 02
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)

#Question 02 part 01
#X = The number of customer calls received in one hour

#Question 02 part 02
λ <- 12

#Question 02 part 03
dpois(15, 12)

