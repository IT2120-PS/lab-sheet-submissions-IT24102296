h<-1
aaa=function(r){
  h<<-h+1
  r<-h+r
  print(r)
}
aaa(3)


h<-1
aaa=function(r){
  h<<-h+1
  r<-h+r
  print(r)
}
aaa(3)

>data1 <-read.tabel("filename.txt",header=TRUE, sep=",")
>data2 <-read.csv("filename.csv",header=TRUE)

data1<-read.table("Data1.txt",header=TRUE,sep=",")
data2<-read.csv("DATA 2.csv", header=TRUE)

fix(data2)

height<-c(12,23,56)
weight<-c(45,78,89)
sheep<-data.frame(height,weight)

fix(sheep)

write.csv(sheep,file="SheepNew.csv")
write.table(sheep,file="Sheeptab1.txt")







