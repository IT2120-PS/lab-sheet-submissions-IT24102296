setwd("C:\\Users\\IT24102296\\Desktop\\IT24102296")


branch_data<-read.table("Exercise (1).txt",header=TRUE)

fix(branch_data)
str(branch_data)
attach(branch_data)

#Variable types & scales
#Sales- Numeric,Ratio
#Advertising-Numeric,Ratio
#Years-Numeric,Ratio
#Branch-Categorical,Nominal


boxplot(branch_data$Sales_X1, main="Boxplot of Sales",outline=TRUE,outpch=8,horizontal=TRUE)
summary(branch_data$Advertising_x2)
IQR(branch_data$Advertising_x2)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
 
  outliers <- which(x < (Q1 - 1.5 * IQR_value) | x > (Q3 + 1.5 * IQR_value))
  return(outliers)
}


outliers_years <- find_outliers(branch_data$Years)
outliers_years
